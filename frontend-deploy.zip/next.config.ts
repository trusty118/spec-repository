import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Clean - no static export
};

export default nextConfig;